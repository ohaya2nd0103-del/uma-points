import {LocalStore} from '../storage.js';
import {catalog} from '../catalog.js';
import {uid,dispatch,balance,preview,scopeKey,scopeLines,settlementDraft,performances} from '../core.js';
import {calendarMigration} from '../game-calendar.js';
const output=document.querySelector('#results');
document.querySelector('#start').onclick=async()=>{
 const button=document.querySelector('#start');button.disabled=true;output.textContent='実行中…\n';
 const name=`uma-qa-${uid()}`,now=Date.parse('2026-11-08T03:00:00Z');let a,b;
 const check=(condition,label)=>{if(!condition)throw new Error(label);output.textContent+=`PASS ${label}\n`;};
 try{
  a=await LocalStore.open(name,catalog,now);check(balance(await a.read())===10000,'初期元本10,000 ptを保存');
  const race={id:uid(),date:'2026-11-08',category:'central',country:'日本',venue:'保存テスト用（手動）',number:1,surface:'unknown',class:'unknown',zone:'Asia/Tokyo',manual:true,sourceIDs:[],startAt:null};
  await a.update(s=>dispatch(s,'raceSave',race,now,catalog));
  const line={id:uid(),raceIds:[race.id],kind:'win',numbers:[1],stake:100};await a.update(s=>dispatch(s,'draftAdd',{lines:[line]},now,catalog));
  a.close();a=await LocalStore.open(name,catalog,now);check((await a.read()).drafts.length===1,'接続を閉じて再度開いても購入予定を復元');
  b=await LocalStore.open(name,catalog,now);const p=preview(await a.read(),now),token=uid();
  await Promise.all(Array.from({length:12},(_,i)=>(i%2?a:b).update(s=>dispatch(s,'purchase',{preview:p,token},now,catalog))));
  let s=await a.read();check(balance(s)===9900&&s.orders.length===1&&s.tickets.length===1,'2接続から12回同時送信しても購入・減算・券面発行は1回');const originalTicket=JSON.stringify(s.tickets[0]);
  const oldOrders=JSON.stringify(s.orders),oldLedger=JSON.stringify(s.ledger);await a.update(s=>calendarMigration(s,now));s=await a.read();check(JSON.stringify(s.orders)===oldOrders&&JSON.stringify(s.ledger)===oldLedger&&s.preferences.calendarMode==='game','旧版の購入・残高を保ったまま年間カレンダーへ移行');
  await a.update(s=>{s.preferences.gameCondition='新馬';calendarMigration(s,now);});s=await a.read();check(s.preferences.gameCondition==='新馬'&&new Set(s.sources.map(x=>x.id)).size===s.sources.length,'繰り返しの移行で設定を保持し出典を重複させない');
  const before=JSON.stringify(s);try{await a.update(s=>{s.preferences.venue='失敗した保存';throw new Error('障害の模擬');});}catch{}
  check(JSON.stringify(await a.read())===before,'書込中の例外で全状態をロールバック');
  const key=scopeKey([race.id]);await a.update(s=>dispatch(s,'settlementInput',{scope:key,lineId:line.id,baseVersion:0,input:{judgment:'win',odds:'2.5'}},now,catalog));
  a.close();a=await LocalStore.open(name,catalog,now);s=await a.read();check(balance(s)===9900&&settlementDraft(s,key,now).inputs[line.id].odds==='2.5','精算下書きの復元・残高への未反映');
  const settleTime=now,settlementToken=uid();await Promise.all([a,b].map(store=>store.update(s=>dispatch(s,'settle',{scope:key,baseVersion:0,token:settlementToken},settleTime,catalog))));
  s=await a.read();check(balance(s)===10150&&s.revisions.length===1,'精算の並行再送も250 ptを1回だけ加算');
  check(performances(s).length===1&&performances(s)[0].day==='2026-11-08'&&s.tickets[0].races[0].startAt===null,'時刻なし購入・即時精算を保存し成績へ反映');
  await a.update(s=>dispatch(s,'settlementInput',{scope:key,lineId:line.id,baseVersion:1,input:{judgment:'win',odds:'1.5'}},settleTime,catalog));
  await a.update(s=>dispatch(s,'settle',{scope:key,baseVersion:1,token:uid()},settleTime,catalog));s=await b.read();check(balance(s)===10050&&s.revisions.at(-1).delta===-100,'精算修正は差額だけ記録し別接続にも保存');
  const month=Date.parse('2027-01-01T00:00:00Z');await Promise.all([a,b].map(store=>store.update(s=>dispatch(s,'refresh',{},month,catalog))));s=await a.read();check(s.grants.length===2&&balance(s)===16050,'2接続の月次補充でも重複配布しない');
  check(JSON.stringify(s.tickets[0])===originalTicket,'精算・修正・月次補充後も券面スナップショットは不変');
  output.textContent+='\n12件成功。実際のブラウザーのIndexedDBで実行しました。';
 }catch(error){output.textContent+=`FAIL ${error.stack||error.message}`;}finally{a?.close();b?.close();indexedDB.deleteDatabase(name);button.disabled=false;}
};
