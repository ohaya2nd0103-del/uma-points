# 公開記録

- アプリURL：https://ohaya2nd0103-del.github.io/uma-points/
- リポジトリ：https://github.com/ohaya2nd0103-del/uma-points
- 公開コミット：`446bdb086c60ff2fa0adc3252ef0fed91008da00`
- GitHub Pages：`main` ブランチ、`/ (root)`、HTTPS。
- 2026年11月8日、公開URLのHTTP 200と、ブラウザーでの初期画面・残高10,000 pt・5タブを確認。
- 公開済みHTML、JSモジュール、CSS、マニフェスト、Service Worker、3種類のアイコンの計12ファイルが、ローカル配布物とバイト単位で一致することを確認。
- Node自動テスト50件成功。実IndexedDBの自動検証9項目成功。ローカルブラウザーで購入・精算・差額修正・再読み込み・分析の一連の操作を確認。
- iPhone Safari実機およびホーム画面からの実機起動は未検証。

公開リポジトリには、アップロード用に1階層へまとめた `dist/` の内容を配置しています。元の開発用構成とテストは、ローカルの `UmaPointsWeb-source.zip` および公開リポジトリ内の `source.zip` に含めています。

GitHub連携APIは新規リポジトリへの書込が403で拒否されたため、ユーザーがサインインしたGitHub画面からアップロードとPages設定を行いました。アプリ利用者のポイント・馬券・精算データはアップロードしていません。
