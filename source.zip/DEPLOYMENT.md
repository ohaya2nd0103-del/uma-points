# 公開記録

- アプリURL：https://ohaya2nd0103-del.github.io/uma-points/
- リポジトリ：https://github.com/ohaya2nd0103-del/uma-points
- 公開コミット：`b6e9cf531d1fdc2c03097299bf9849fe7ad173e5`
- GitHub Pages：`main` ブランチ、`/ (root)`、HTTPS。
- 2026年11月8日、公開URLのHTTP 200と、ブラウザーでの初期画面・残高10,000 pt・5タブを確認。
- 公開済みHTML、JSモジュール、CSS、マニフェスト、Service Worker、3種類のアイコン、README、検証記録、ソースZIPの計18ファイルが、ローカル配布物とバイト単位で一致することを確認。
- 共通年間カレンダーに統合。中央GⅠ24・GⅡ38・GⅢ68、地方GⅠ1・JpnⅠ12・JpnⅡ12・JpnⅢ21を内蔵。一般競走を含め1,572レース・51週枠。中央の週枠は参考番組表、地方46件はNAR公式2026年一覧に基づく。週枠は年間目安として表示し、実施日時を保証しない。
- Node自動テスト73件成功。実IndexedDBの自動検証11項目成功。地方JpnⅢの購入・精算、旧13地方番組IDの維持、移行時の残高・購入・精算・券面保持を確認。ブラウザーで佐賀記念から開催設定を保存できることを確認。
- 公開版で旧Service Workerの更新通知 → 設定「更新して再読み込み」→ 共通カレンダーを確認。残高10,000 ptを維持。11月2週のⅠ・Ⅱ・Ⅲの3色、3月4週で中央GⅠ〜Ⅲと地方JpnⅡ・Ⅲの同時表示を確認。画像は `../uma-points-graded-calendar.jpg` と `../uma-points-central-local-calendar.jpg`。
- iPhone Safari実機およびホーム画面からの実機起動は未検証。

公開リポジトリには、アップロード用に1階層へまとめた `dist/` の内容を配置しています。元の開発用構成とテストは、ローカルの `UmaPointsWeb-source.zip` および公開リポジトリ内の `source.zip` に含めています。

GitHub連携APIは新規リポジトリへの書込が403で拒否されたため、ユーザーがサインインしたGitHub画面からアップロードとPages設定を行いました。アプリ利用者のポイント・馬券・精算データはアップロードしていません。
