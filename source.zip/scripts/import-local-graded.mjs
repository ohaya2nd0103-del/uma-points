// NAR公式の年間一覧から、地方ダートグレード競走の事実項目を取り込む。
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(process.argv[2],'utf8');
const value=(html,css)=>html.match(new RegExp(`<p class="${css}">([^<]+)</p>`))?.[1]?.trim();
const rows=[];
for(const match of html.matchAll(/<li class="([^"]+)">([\s\S]*?)<\/li>/g)){
 const [,classes,body]=match,grade=body.match(/<p class="icon --grade">((?:Jpn|G)[ⅠⅡⅢ]+)<\/p>/)?.[1];
 if(!grade)continue;
 const name=value(body,'name'),[month,day]=value(body,'date').split('/').map(Number);
 const age=/\bage_2\b/.test(classes)?'2歳':/\bage_3\b/.test(classes)?'3歳':name==='帝王賞'||month<6?'4歳上':'3歳上';
 rows.push({id:'annual-local-'+createHash('sha256').update(name).digest('hex').slice(0,16),month,day,name,grade,venue:value(body,'area'),distance:Number(value(body,'course').replace('m','')),age,symbols:/\bmare\b/.test(classes)?['牝']:[],referenceDate:`2026-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`});
}
assert.equal(rows.length,46);assert.equal(new Set(rows.map(r=>r.name)).size,46);
assert.deepEqual(Object.fromEntries(['GⅠ','JpnⅠ','JpnⅡ','JpnⅢ'].map(g=>[g,rows.filter(r=>r.grade===g).length])),{'GⅠ':1,'JpnⅠ':12,'JpnⅡ':12,'JpnⅢ':21});
const data={checkedOn:'2026-11-08',referenceYear:2026,weekBasis:'2026年NAR公式日程の月・日から1〜7日を1週、8〜14日を2週として配置。5週枠がない月の月末は最終週へ集約。毎年の実施日を保証するものではありません。',sources:[{id:'nar-graded-2026',title:'NAR公式 重賞競走一覧（2026年）',url:'https://www.keiba.go.jp/gradedrace/schedule_2026.html',checkedOn:'2026-11-08',coverage:'地方開催のGⅠ1・JpnⅠ12・JpnⅡ12・JpnⅢ21の計46競走。名称・格・競馬場・距離・実施日を確認。年間カレンダーでは月・週の目安に配置。JBCの開催場・距離は2026年の金沢開催を使用。'}],rows};
fs.writeFileSync(path.join(root,'data/local-graded-programs.json'),JSON.stringify(data,null,2)+'\n');
fs.writeFileSync(path.join(root,'local-graded-programs.js'),'// NAR公式2026年日程の事実項目。週枠はアプリ内の年間目安。\nexport const localGradedData = '+JSON.stringify(data)+';\n');
console.log(JSON.stringify({localGraded:rows.length,grades:Object.fromEntries(['GⅠ','JpnⅠ','JpnⅡ','JpnⅢ'].map(g=>[g,rows.filter(r=>r.grade===g).length]))}));
