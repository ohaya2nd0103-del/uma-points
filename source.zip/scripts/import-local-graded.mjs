// NAR公式の年間一覧から、地方独自の格・ばんえいを含めた重賞の事実項目を取り込む。
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(process.argv[2],'utf8');
const value=(html,css)=>html.match(new RegExp(`<p class="${css}">([^<]+)</p>`))?.[1]?.trim();
const previous=JSON.parse(fs.readFileSync(path.join(root,'data/local-graded-programs.json'),'utf8'));
const rows=[];
for(const match of html.matchAll(/<li class="([^"]+)">([\s\S]*?)<\/li>/g)){
 const [,classes,body]=match;if(!classes.split(' ').includes('display'))continue;
 const grade=body.match(/<p class="icon --(?:grade|other)">([^<]+)<\/p>/)?.[1]?.trim()||'重賞';
 assert.ok(value(body,'name')&&value(body,'date')&&value(body,'area')&&value(body,'course'),'未解析の重賞行');
 const name=value(body,'name'),[month,day]=value(body,'date').split('/').map(Number);
 const venue=value(body,'area'),national=/^(?:Jpn|G)[ⅠⅡⅢ]+$/.test(grade),exactAge=classes.match(/\bage_(\d)\b/)?.[1];
 const age=exactAge?`${exactAge}歳`:national?previous.rows.find(r=>r.name===name&&r.venue===venue)?.age||'不明':'不明';
 const course=value(body,'course'),distance=Number(course.match(/\d+/)?.[0]);assert.ok(/^(?:芝)?\d+m$/.test(course)&&Number.isInteger(distance)&&distance>0,'距離・馬場を解析できません: '+name);
 rows.push({id:'annual-local-'+createHash('sha256').update(national?name:venue+':'+name).digest('hex').slice(0,16),month,day,name,grade,gradeFamily:national?'national':'regional',venue,surface:venue==='帯広'?'banei':course.startsWith('芝')?'turf':'dirt',distance,age,symbols:/\bmare\b/.test(classes)?['牝']:[],referenceDate:`2026-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`});
}
assert.equal(rows.length,345);assert.equal(new Set(rows.map(r=>r.venue+':'+r.name)).size,345);
assert.equal(rows.filter(r=>r.gradeFamily==='national').length,46);
assert.deepEqual(Object.fromEntries(['GⅠ','JpnⅠ','JpnⅡ','JpnⅢ'].map(g=>[g,rows.filter(r=>r.grade===g).length])),{'GⅠ':1,'JpnⅠ':12,'JpnⅡ':12,'JpnⅢ':21});
const data={checkedOn:'2026-11-08',referenceYear:2026,weekBasis:'2026年NAR公式日程の月・日から1〜7日を1週、8〜14日を2週として配置。5週枠がない月の月末は最終週へ集約。毎年の実施日を保証するものではありません。',sources:[{id:'nar-graded-2026',title:'NAR公式 重賞競走一覧（2026年）',url:'https://www.keiba.go.jp/gradedrace/schedule_2026.html',checkedOn:'2026-11-08',coverage:'一覧掲載の地方重賞345競走を収録。GⅠ・JpnⅠ〜Ⅲの46競走に、S・SP・H・M・BG・重賞Ⅰ/Ⅱ・格表記のない重賞299競走を追加。名称・格・競馬場・距離・実施日を確認。年齢条件を確定できない行は不明。週は年間目安、JBCの条件は2026年の金沢開催。地域独自の格をG・Jpnに換算しません。'}],rows};
fs.writeFileSync(path.join(root,'data/local-graded-programs.json'),JSON.stringify(data,null,2)+'\n');
fs.writeFileSync(path.join(root,'local-graded-programs.js'),'// NAR公式2026年日程の事実項目。週枠はアプリ内の年間目安。\nexport const localGradedData = '+JSON.stringify(data)+';\n');
console.log(JSON.stringify({localGraded:rows.length,grades:Object.fromEntries(['GⅠ','JpnⅠ','JpnⅡ','JpnⅢ'].map(g=>[g,rows.filter(r=>r.grade===g).length]))}));
