// GitHubのWebアップロードでも一度に配置できるよう、公開物を1階層にまとめる。
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
fs.mkdirSync(dist,{recursive:true});
const files=['index.html','styles.css','app.js','core.js','storage.js','catalog.js','tickets.js','game-calendar.js','game-programs.js','local-graded-programs.js','manifest.webmanifest','sw.js','.nojekyll'];
for(const name of files){const text=fs.readFileSync(path.join(root,name),'utf8').replaceAll('./icons/','./');fs.writeFileSync(path.join(dist,name),text);}
for(const name of ['apple-touch-icon.png','icon-192.png','icon-512.png'])fs.copyFileSync(path.join(root,'icons',name),path.join(dist,name));
fs.copyFileSync(path.join(root,'TEST_REPORT.md'),path.join(dist,'TEST_REPORT.md'));
fs.copyFileSync(path.join(root,'PUBLIC_README.md'),path.join(dist,'README.md'));
const html=fs.readFileSync(path.join(dist,'index.html'),'utf8');for(const match of html.matchAll(/(?:src|href)="\.\/([^"#]+)"/g))assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'manifest.webmanifest'),'utf8'));for(const icon of manifest.icons)assert.ok(fs.existsSync(path.join(dist,icon.src)),icon.src);
const sw=fs.readFileSync(path.join(dist,'sw.js'),'utf8');for(const match of sw.matchAll(/'\.\/([^']*)'/g))if(match[1])assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
console.log(`Built ${fs.readdirSync(dist).length} flat static files. HTML, manifest and offline asset paths verified.`);
