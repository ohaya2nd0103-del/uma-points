// GitHubのWebアップロードでも一度に配置できるよう、公開物を1階層にまとめる。
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
fs.mkdirSync(dist,{recursive:true});
const files=['index.html','styles.css','app.js','core.js','storage.js','catalog.js','tickets.js','game-calendar.js','game-programs.js','manifest.webmanifest','sw.js','.nojekyll'];
for(const name of files){const text=fs.readFileSync(path.join(root,name),'utf8').replaceAll('./icons/','./');fs.writeFileSync(path.join(dist,name),text);}
for(const name of ['apple-touch-icon.png','icon-192.png','icon-512.png'])fs.copyFileSync(path.join(root,'icons',name),path.join(dist,name));
fs.copyFileSync(path.join(root,'TEST_REPORT.md'),path.join(dist,'TEST_REPORT.md'));
fs.writeFileSync(path.join(dist,'README.md'),`# うまポイント\n\n[アプリを開く](https://ohaya2nd0103-del.github.io/uma-points/)\n\niPhoneのSafariで開き、共有 →「ホーム画面に追加」で使えます。架空ポイント・換金不可。現金・実際の投票・課金はありません。\n\n## ダビスタ2参考のカレンダー\n\nNintendo Switch 2版の攻略サイトの番組表を参考に、月・週・競馬場・クラスで探せます。1,539番組に新馬106件・未勝利175件、1〜3勝クラス、OP・重賞を含みます。\n\n[参考番組表](https://ds2.yublog.com/info/race_program.php)と同ページの公開JSONから番組の事実項目だけを取り込みました。確認日2026年11月8日、画像転記データ版2026-10-09.v3。元メタデータではゲーム名・版は未特定とされており、公式との完全一致・網羅性は保証しません。画像やサイトの文章・UIは同梱していません。\n\nゲームの月・週を実日付に変換せず、番組を選んでアプリ内の開催日・番号・購入締切を設定します。新馬でも購入・精算・保存・分析へ進めます。購入・残高・既存履歴は初期化せず維持します。旧画面のままなら設定から「更新して再読み込み」を使ってください。サイトデータの削除は不要です。\n\n## ポイントと保存\n\n初期元本10,000 pt、翌月から月3,000 pt。払戻は倍率によるシミュレーションで1 pt未満切り捨て。購入・精算・履歴は端末内のIndexedDBに保存し、GitHubへ送信しません。ブラウザーのサイトデータを消すと復元できません。\n\nWeb版にバックグラウンド通知・触覚はありません。写真保存は共有メニューまたはPNG出力です。iOS Safari実機は未検証です。\n\n[検証記録](TEST_REPORT.md) · [開発用ソース一式](source.zip)\n\n65件のNode自動テストと11項目の実IndexedDB検証が成功しました。開発用ソースZIPには詳細READMEとテスト・サーバー・取込スクリプトを含みます。公開物はビルド不要の静的HTML/CSS/JavaScriptです。\n`);
const html=fs.readFileSync(path.join(dist,'index.html'),'utf8');for(const match of html.matchAll(/(?:src|href)="\.\/([^"#]+)"/g))assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'manifest.webmanifest'),'utf8'));for(const icon of manifest.icons)assert.ok(fs.existsSync(path.join(dist,icon.src)),icon.src);
const sw=fs.readFileSync(path.join(dist,'sw.js'),'utf8');for(const match of sw.matchAll(/'\.\/([^']*)'/g))if(match[1])assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
console.log(`Built ${fs.readdirSync(dist).length} flat static files. HTML, manifest and offline asset paths verified.`);
