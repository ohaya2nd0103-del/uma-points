// GitHubのWebアップロードでも一度に配置できるよう、公開物を1階層にまとめる。
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
fs.mkdirSync(dist,{recursive:true});
const files=['index.html','styles.css','app.js','core.js','storage.js','catalog.js','tickets.js','manifest.webmanifest','sw.js','.nojekyll'];
for(const name of files){const text=fs.readFileSync(path.join(root,name),'utf8').replaceAll('./icons/','./');fs.writeFileSync(path.join(dist,name),text);}
for(const name of ['apple-touch-icon.png','icon-192.png','icon-512.png'])fs.copyFileSync(path.join(root,'icons',name),path.join(dist,name));
fs.copyFileSync(path.join(root,'TEST_REPORT.md'),path.join(dist,'TEST_REPORT.md'));
fs.writeFileSync(path.join(dist,'README.md'),`# うまポイント\n\n[アプリを開く](https://ohaya2nd0103-del.github.io/uma-points/)\n\niPhoneのSafariで開き、共有メニュー →「ホーム画面に追加」→「追加」で使えます。現金・実際の投票・換金・課金はありません。\n\nポイント管理・購入予定・長押し購入・紙馬券・精算下書き・差額修正・履歴・分析を、端末内のIndexedDBで保存します。初期元本10,000 pt、翌月から月3,000 pt。払戻は倍率によるシミュレーションで、1 pt未満を切り捨てます。\n\n購入・履歴のデータはGitHubへ送信しません。アプリのソースは公開されています。ブラウザーのサイトデータを消すと復元できません。継続利用するホーム画面アイコンから使用してください。\n\nWeb版ではバックグラウンドの発走10分前通知と触覚はありません。画像保存は共有メニューまたはPNGダウンロードです。iOS Safari実機・ホーム画面追加後の動作は未検証です。\n\n公式データは2026年第5回東京競馬の確認済み重賞5競走のみ。発走時刻・頭数・発売券種は未登録で、時刻補完と手動レース登録を用意しています。一般競走・地方・海外・2027年度の個別レースは未収録です。\n\n[検証記録](TEST_REPORT.md) · [開発用ソース一式](source.zip)\n\n公開版はビルド不要のHTML/CSS/JavaScriptです。開発用ソース一式には詳細README、50件のNodeテスト、実IndexedDBの9項目の検証ページ、開発サーバー、GitHub Actionsのテスト定義を含めています。テスト定義は開発用ZIP内です。\n`);
const html=fs.readFileSync(path.join(dist,'index.html'),'utf8');for(const match of html.matchAll(/(?:src|href)="\.\/([^"#]+)"/g))assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'manifest.webmanifest'),'utf8'));for(const icon of manifest.icons)assert.ok(fs.existsSync(path.join(dist,icon.src)),icon.src);
const sw=fs.readFileSync(path.join(dist,'sw.js'),'utf8');for(const match of sw.matchAll(/'\.\/([^']*)'/g))if(match[1])assert.ok(fs.existsSync(path.join(dist,match[1])),match[1]);
console.log(`Built ${fs.readdirSync(dist).length} flat static files. HTML, manifest and offline asset paths verified.`);
