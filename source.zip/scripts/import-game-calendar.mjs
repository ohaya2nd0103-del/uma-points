// 取得済みの公開番組JSONから、番組の事実項目だけを取り込む。サイトの文章・画像・UIは同梱しない。
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
if(!process.argv[2])throw new Error('取得済みJSONのパスを指定してください。');
const source=JSON.parse(fs.readFileSync(path.resolve(process.argv[2]),'utf8'));
assert.ok(Array.isArray(source.races)&&Array.isArray(source.periods));
assert.equal(new Set(source.races.map(r=>r.id)).size,source.races.length);
const venues=[...new Set(source.races.map(r=>r.venue))].sort();
const rows=source.races.map(r=>{
 assert.ok(source.periods.some(p=>p.id===r.period_id));
 assert.ok(['新馬','未勝利','1勝クラス','2勝クラス','3勝クラス','OP'].includes(r.class));
 assert.ok(['turf','dirt'].includes(r.surface)&&Number.isInteger(r.distance_m));
 return [r.id.replace(/^race_/,''),r.period_id,venues.indexOf(r.venue),r.meeting_number,r.age.raw,r.class,r.race_name||'',r.surface==='turf'?'t':'d',r.distance_m,r.grade_raw||'',r.type_symbols,r.source_id,r.source_excel_row];
});
const data={version:1,edition:'Nintendo Switch 2版参考',checkedOn:'2026-11-08',datasetVersion:source.metadata.dataset_version,provenance:'image_transcription',editionVerified:false,
 coverageNote:'Switch 2版攻略サイトで公開された画像転記の番組データを参考にしています。元データのメタデータではゲーム名・版は未特定とされており、公式番組との完全一致や網羅性を保証しません。実日付・発走時刻・レース番号は未収録です。',
 sources:[{id:'ds2-game-program-reference',title:'Switch2版湯一路ダビスタページ・番組表（参考資料）',url:'https://ds2.yublog.com/info/race_program.php',checkedOn:'2026-11-08',coverage:'月・週・競馬場・年齢・クラス・レース名・馬場・距離・格の参考データ。画像転記。版・網羅性は未確認。現実の開催日程ではありません。'},
 {id:'ds2-game-program-data',title:'番組データ（画像転記・公開JSON）',url:'https://ds2.yublog.com/info/race_program/data/race_schedule.json',checkedOn:'2026-11-08',coverage:`データ版 ${source.metadata.dataset_version}、${source.races.length}番組・${source.periods.length}週枠。サイトのCSV出力に使われる公開データ。実日付・時刻・レース番号はありません。`},
 {id:'ds2-official-faq',title:'ダービースタリオン2 公式FAQ',url:'https://www.gameaddict.co.jp/derbystallion2/faq.php',checkedOn:'2026-11-08',coverage:'Switch 2版と地方競馬場・収録レース、JRA番組を基にした構成を確認。個別の週・一般戦の全件照合はしていません。'}],
 periods:source.periods.map(p=>({id:p.id,month:p.month,week:p.week,label:p.label})),venues,rows};
fs.writeFileSync(path.join(root,'data/game-programs.json'),JSON.stringify(data,null,2)+'\n');
fs.writeFileSync(path.join(root,'game-programs.js'),'// 公開番組の事実項目。出典・収録上の制限はmetaを参照。\nexport const gameProgramData = '+JSON.stringify(data)+';\n');
console.log(JSON.stringify({programs:rows.length,periods:data.periods.length,debut:rows.filter(r=>r[5]==='新馬').length,maiden:rows.filter(r=>r[5]==='未勝利').length,venues:venues.length}));
