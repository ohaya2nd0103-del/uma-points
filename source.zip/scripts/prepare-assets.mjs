import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source = JSON.parse(fs.readFileSync(path.join(root,'data/races.json'),'utf8'));
const catalog = {...source,races:source.races.map(r => ({id:r.id,date:r.localDate,category:r.category,country:r.country,venue:r.venue,number:r.number,name:r.name,surface:r.surface,distance:r.distance,grade:r.grade,class:r.raceClass,startAt:r.startAt || null,zone:r.timeZoneID,sourceIDs:r.sourceIDs,checkedOn:r.checkedOn,manual:r.isManual,confirmedKinds:r.confirmedKinds || null}))};
fs.writeFileSync(path.join(root,'catalog.js'),`// 公式資料で確認した開催事実のみ。更新元: data/races.json\nexport const catalog = ${JSON.stringify(catalog,null,2)};\n`);
function crc32(data){let c=0xffffffff;for(const b of data){c^=b;for(let i=0;i<8;i++)c=c&1?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function chunk(name,data){const type=Buffer.from(name),size=Buffer.alloc(4),crc=Buffer.alloc(4);size.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([type,data])));return Buffer.concat([size,type,data,crc]);}
for(const size of [180,192,512]){
 const raw=Buffer.alloc((size*3+1)*size);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const xx=x/size*1024,yy=y/size*1024;let color=[245,246,243];
  if(xx>=163&&xx<=861&&yy>=263&&yy<=761)color=[30,82,65];
  if(Math.hypot(xx-163,yy-512)<37||Math.hypot(xx-861,yy-512)<37)color=[245,246,243];
  if((xx>=235&&xx<=390&&yy>=344&&yy<=421)||(xx>=235&&xx<=620&&yy>=470&&yy<=498)||(xx>=235&&xx<=705&&yy>=535&&yy<=563)||(xx>=235&&xx<=540&&yy>=635&&yy<=668)||(xx>=751&&xx<=759&&yy>=324&&yy<=700&&Math.floor(yy/29)%2===0))color=[246,244,219];
  const i=y*(size*3+1)+1+x*3;raw[i]=color[0];raw[i+1]=color[1];raw[i+2]=color[2];
 }
 const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(size,0);ihdr.writeUInt32BE(size,4);ihdr[8]=8;ihdr[9]=2;
 const png=Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]);
 fs.mkdirSync(path.join(root,'icons'),{recursive:true});fs.writeFileSync(path.join(root,'icons',size===180?'apple-touch-icon.png':`icon-${size}.png`),png);
}
console.log('Prepared official catalog module and PWA icons.');
