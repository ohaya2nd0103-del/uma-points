import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=[];
function walk(directory){for(const item of fs.readdirSync(directory,{withFileTypes:true})){if(['node_modules','.git','test-results','dist'].includes(item.name))continue;const absolute=path.join(directory,item.name);if(item.isDirectory())walk(absolute);else{const name=path.relative(root,absolute).replaceAll('\\','/'),data=fs.readFileSync(absolute);files.push({path:name,encoding:name.endsWith('.png')?'base64':'utf-8',content:data.toString(name.endsWith('.png')?'base64':'utf8')});}}}
walk(root);process.stdout.write(JSON.stringify(files));
